
<div align="center">

# Minecraft server website
Simple, clean website for minecraft servers. Everything is customizable.
<br>
<br>
![image](https://i.imgur.com/pM5JUDS.png)

https://berozgaar.ga/
</div>
